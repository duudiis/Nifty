module.exports = class Loaders {

    constructor(client) {
        this.client = client;
        
        this.name = "";
    }

}