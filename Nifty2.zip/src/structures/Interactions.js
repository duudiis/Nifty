module.exports = class Interactions {

    constructor(client) {
        this.client = client;
        
        this.name = "";
    }

}