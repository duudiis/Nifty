module.exports = class Events {

    constructor(client) {
        this.client = client;
        
        this.name = "";
    }

}