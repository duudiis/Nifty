module.exports = class Modules {

    constructor(client) {
        this.client = client;
        
        this.name = "";
        this.subcategory = null;
    }

}